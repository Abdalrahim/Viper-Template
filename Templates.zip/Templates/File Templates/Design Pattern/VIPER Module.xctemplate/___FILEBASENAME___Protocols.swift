
//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

// MARK: ___VARIABLE_ModuleName___Protocol: Protocol declaration for Presenter

protocol ___VARIABLE_ModuleName___ViewInterface {
    var view: ___VARIABLE_ModuleName___PresenterInterface? {get set}
    var interactor: ___VARIABLE_ModuleName___InteractorInterface? {get set}
    var router: ___VARIABLE_ModuleName___RouterInterface? {get set}
    
    func viewDidLoad()
    
    func viewDidDisappear(_ animated: Bool)
    
    func viewWillAppear(_ animated: Bool)
    
    func viewWillDisappear(_ animated: Bool)
    
    func viewDidAppear(_ animated: Bool)
}

// MARK: Protocol for ___VARIABLE_ModuleName___ ViewController

protocol ___VARIABLE_ModuleName___PresenterInterface {
    func setupUI()
}

// MARK: Protocol for ___VARIABLE_ModuleName___ Interactor

protocol ___VARIABLE_ModuleName___InteractorInterface {
    
}

// MARK: Protocol for ___VARIABLE_ModuleName___ Router

protocol ___VARIABLE_ModuleName___RouterInterface {
    static func buildModule() -> ___VARIABLE_ModuleName___Controller
}
