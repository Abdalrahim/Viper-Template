//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

// MARK: ___VARIABLE_ModuleName___Controller: UI Module

import UIKit

class ___VARIABLE_ModuleName___Controller: UIViewController {
    
    // MARK: Properties

    var presenter: ___VARIABLE_ModuleName___ViewInterface?
    
    init() {
        super.init(nibName:"___VARIABLE_ModuleName___", bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("___VARIABLE_ModuleName___Controller init(coder:) has not been implemented")
    }
}

// MARK: ___VARIABLE_ModuleName___Controller  - Lifecycle Methods

extension ___VARIABLE_ModuleName___Controller {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.presenter?.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.presenter?.viewDidAppear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.presenter?.viewWillAppear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        self.presenter?.viewDidDisappear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.presenter?.viewWillDisappear(animated)
    }
}

// MARK: ___VARIABLE_ModuleName___Controller - Setup Methods

extension ___VARIABLE_ModuleName___Controller: ___VARIABLE_ModuleName___PresenterInterface {
    
    func setupUI() {
        
    }
    
}
