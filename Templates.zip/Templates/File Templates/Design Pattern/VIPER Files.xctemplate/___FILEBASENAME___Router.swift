
//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import UIKit

// MARK: ___VARIABLE_ModuleName___Router: ___VARIABLE_ModuleName___RouterInterface

class ___VARIABLE_ModuleName___Router: ___VARIABLE_ModuleName___RouterInterface {
    
    // MARK: - Module setup -
    
    static func buildModule() -> ___VARIABLE_ModuleName___Controller {
        
        let view = ___VARIABLE_ModuleName___Controller()
        
        var presenter : ___VARIABLE_ModuleName___ViewInterface = ___VARIABLE_ModuleName___Presenter()
        let interactor : ___VARIABLE_ModuleName___InteractorInterface = ___VARIABLE_ModuleName___Interactor()
        let router : ___VARIABLE_ModuleName___RouterInterface = ___VARIABLE_ModuleName___Router()
        
        view.presenter = presenter
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        
        return view
    }

}
