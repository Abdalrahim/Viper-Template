
//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Foundation

// MARK: ___VARIABLE_ModuleName___Presenter

class ___VARIABLE_ModuleName___Presenter : ___VARIABLE_ModuleName___ViewInterface {
    
    var view: ___VARIABLE_ModuleName___PresenterInterface?
    var router: ___VARIABLE_ModuleName___RouterInterface?
    var interactor : ___VARIABLE_ModuleName___InteractorInterface?
    
    init() {
        
    }
    
    deinit {
        
    }
}

// MARK: ___VARIABLE_ModuleName___Presenter - Lifecycle methods

extension ___VARIABLE_ModuleName___Presenter {
    
    func viewDidLoad() {
        self.view?.setupUI()
    }
    
    func viewDidAppear(_ animated: Bool) {}
    
    func viewDidDisappear(_ animated: Bool) {}
    
    func viewWillAppear(_ animated: Bool) {}
    
    func viewWillDisappear(_ animated: Bool) {}
    
}

// MARK: ___VARIABLE_ModuleName___Presenter - Interactor requests

extension ___VARIABLE_ModuleName___Presenter {
    
    
}
