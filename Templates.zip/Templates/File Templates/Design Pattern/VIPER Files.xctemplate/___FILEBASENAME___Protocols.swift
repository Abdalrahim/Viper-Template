
//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  ___COPYRIGHT___
//

import Foundation
import UIKit

protocol ___VARIABLE_ModuleName___ViewInterface: BaseViewInterface {
    var view: ___VARIABLE_ModuleName___PresenterInterface? {get set}
    var interactor: ___VARIABLE_ModuleName___InteractorInterface? {get set}
    var router: ___VARIABLE_ModuleName___RouterInterface? {get set}
}

protocol ___VARIABLE_ModuleName___PresenterInterface: BasePresenterInterface {
    func setupUI()
}

protocol ___VARIABLE_ModuleName___InteractorInterface {
    
}

protocol ___VARIABLE_ModuleName___RouterInterface {
    static func buildModule() -> ___VARIABLE_ModuleName___Controller
}
